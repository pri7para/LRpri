export default {
  entry: "src/main.js",
  dest: "build/bundle.js",
  format: "cjs"
}
